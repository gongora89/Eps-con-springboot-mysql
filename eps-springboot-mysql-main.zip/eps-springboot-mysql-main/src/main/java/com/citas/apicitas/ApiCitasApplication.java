package com.citas.apicitas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCitasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCitasApplication.class, args);
	}

}

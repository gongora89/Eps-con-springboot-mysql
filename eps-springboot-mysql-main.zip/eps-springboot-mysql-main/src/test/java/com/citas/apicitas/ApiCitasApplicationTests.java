package com.citas.apicitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
